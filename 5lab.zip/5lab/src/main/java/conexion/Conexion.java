package conexion;

import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;

import transactions.LockMode;
import transactions.ThreadMode;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;



public class Conexion {
    private static String address = "192.168.56.10";
    private static String database= "currency_control";
    public Connection connection = null;
    protected Boolean lock;
    protected LockMode lockMode;

    public Conexion(String username, String password) throws SQLException {
        this.connect(username, password, address, database);
    }

    public void connect(String username, String password, String host, String database) throws SQLException {
        MysqlDataSource mysqlDataSource = new MysqlDataSource();
        mysqlDataSource.setUser(username);
        mysqlDataSource.setPassword(password);
        mysqlDataSource.setServerName(host);
        mysqlDataSource.setDatabaseName(database);

        if(this.connection != null) {
            this.connection.close();
            this.connection = null;
        }

        this.connection = mysqlDataSource.getConnection();
        this.connection.setAutoCommit(false);
    }

    public ResultSet executeQuery(String query) throws SQLException {
        
    	if(this.connection == null || this.connection.isClosed()) throw new SQLException("There is no active connection or the connection has already been closed.");

        Statement statement = this.connection.createStatement();

        return statement.executeQuery(query);
    }

    public boolean isConnected() {
        return connection != null;
    }

    public void executeUpdate(String sql) throws SQLException {
        if(this.connection == null || this.connection.isClosed()) throw new SQLException("There is no active connection or the connection has already been closed.");

        Statement statement = connection.prepareStatement(sql);
        statement.executeUpdate(sql);

        statement.close();
    }

    public void dispatch() throws SQLException {
        this.connection.close();
    }

    public void setLocking(ThreadMode threadMode) {
        this.lock = threadMode == ThreadMode.LOCKING;
    }

    public void setLockMode(LockMode lockMode){
        this.lockMode = lockMode;
    };
}
