package conexion;

import transactions.LockMode;
import transactions.NoResultException;

import java.sql.ResultSet;
import java.sql.SQLException;

public class Data extends Conexion {
    private static final String EXCLUSIVE_LOCK_STRING = "FOR UPDATE";
    private static final String SHARE_LOCK_STRING = "LOCK IN SHARE MODE";
    private String logName;

    public Data(String username, String password, String logName) throws SQLException {
        super(username, password);
        this.logName = logName;
    }

    protected String getLockString() {
        if(this.lockMode == LockMode.EXCLUSIVE) return EXCLUSIVE_LOCK_STRING; else return SHARE_LOCK_STRING;
    }

    public void showValues() throws SQLException, NoResultException {
        try{
        	System.out.println(
                    "X : " + String.valueOf(this.getXValue())
                    + ", Y : " + String.valueOf(this.getYValue())
                    + ", Z: " + String.valueOf(this.getZValue())
                    + ", W: " + String.valueOf(this.getWValue())
                    + ", S: " + String.valueOf(this.getSValue())
                    + ", C: " + String.valueOf(this.getCValue())
                    + ", F: " + String.valueOf(this.getFValue())
                    + ", U: " + String.valueOf(this.getUValue())
                    + ", V: " + String.valueOf(this.getVValue())
                    + ", I: " + String.valueOf(this.getIValue())
            );
        	this.commit();
    } catch (SQLException e){
    	this.rollback();
    	e.printStackTrace();
    }
       
    }

    public void initializeVariables() throws SQLException {
        try{
        	this.setXValue(0);
            this.setYValue(0);
            this.setZValue(0);
            this.setWValue(0);
            this.setSValue(0);
            this.setCValue(0);
            this.setFValue(0);
            this.setUValue(0);
            this.setVValue(0);
            this.setIValue(0);
            this.commit();
        } catch (SQLException e) { 
        	this.rollback();
        }
    	
    }

    private int getXValue() throws SQLException, NoResultException {
        return this.getValue("X");
    }

    private void setXValue(int value) throws SQLException {
        this.setValue("X", value);
    }

    private int getYValue() throws SQLException, NoResultException {
        return this.getValue("Y");
    }
    
    private int getVValue() throws SQLException, NoResultException {
        return this.getValue("V");
    }
    
    private int getUValue() throws SQLException, NoResultException {
        return this.getValue("U");
    }

    private void setYValue(int value) throws SQLException {
        this.setValue("Y", value);
    }
    
    private void setIValue(int value) throws SQLException {
        this.setValue("I", value);
    }
    private int getIValue() throws SQLException, NoResultException {
        return this.getValue("I");
    }
    private int getZValue() throws SQLException, NoResultException {
        return this.getValue("Z");
    }

    private void setZValue(int value) throws SQLException {
        this.setValue("Z", value);
    }
    
    private void setVValue(int value) throws SQLException {
        this.setValue("V", value);
    }
    
    private void setUValue(int value) throws SQLException {
        this.setValue("U", value);
    }

    private int getWValue() throws SQLException, NoResultException {
        return this.getValue("W");
    }

    private void setWValue(int value) throws SQLException {
        this.setValue("W", value);
    }

    private int getCValue() throws SQLException, NoResultException {
        return this.getValue("C");
    }

    private void setCValue(int value) throws SQLException {
        this.setValue("C", value);
    }

    private int getFValue() throws SQLException, NoResultException {
        return this.getValue("F");
    }
    private void setFValue(int value) throws SQLException {
        this.setValue("F", value);
    }

    private int getSValue() throws SQLException, NoResultException {
        return this.getValue("S");
    }

    private void setSValue(int value) throws SQLException {
        this.setValue("S", value);
    }



    private int getValue(String variableName) throws SQLException, NoResultException {
        ResultSet resultSet = this.executeQuery(
                "SELECT value FROM variables WHERE name = '"
                        + variableName
                        + "'"+
                        (this.lock ? this.getLockString() : ""));
        if(resultSet == null) throw new NoResultException();

        resultSet.next();
        return resultSet.getInt(1);
    }

    private void setValue(String variableName, int value) throws SQLException {
        System.out.println("Transaction:" + this.logName + ", the variable " + variableName + " is now set to " + value);
        this.executeUpdate("UPDATE variables SET value = '" + String.valueOf(value) + "' WHERE name = '" + variableName + "'");
    }

    public void transactionA()throws SQLException, NoResultException {
        try {
        	this.setXValue(this.getXValue() + 1);
            this.setYValue(this.getYValue() - 1);
            this.setUValue(this.getUValue() + 1);
            this.setVValue(this.getVValue() - 1);
            this.commit();
        }catch (SQLException e){
			this.rollback();
		}
    }

    public void transactionB()throws SQLException, NoResultException{
        try {
        	this.setVValue(this.getVValue() + 1);
            this.setUValue(this.getUValue() - 1);
            this.setYValue(this.getYValue() + 1);
            this.setXValue(this.getXValue() - 1);
            this.commit();
        } catch (SQLException e){
        	this.rollback();
		}
   	
    }

    public void transactionC() throws SQLException, NoResultException {
    	try {
	    	int X = this.getXValue();
	        int Y = this.getYValue();
	        int U = this.getUValue();
	        int V = this.getVValue();
	        int C = this.getCValue();
	        int S = this.getSValue();
	
	        this.setCValue(C+X+Y+U+V);
	        this.setSValue(S+X+Y+U+V);
	        this.commit();
	        
    	}catch (SQLException e){
			this.rollback();
		
		}
	   
    }

    public void transactionD() throws SQLException, NoResultException {
    	try {
    		this.setVValue(this.getVValue() + 1);
            this.setUValue(this.getUValue() - 1);
            this.setWValue(this.getWValue() + 1);
            this.setZValue(this.getZValue() - 1);
            this.commit();
	        
    	}catch (SQLException e){
		   this.rollback();
	   }
    	
    }

    public void transactionE() throws SQLException, NoResultException {
        try{
    	this.setZValue(this.getZValue() + 1);
        this.setWValue(this.getWValue() - 1);
        this.setUValue(this.getUValue() + 1);
        this.setVValue(this.getVValue() - 1);
        this.commit();
        
	}catch (SQLException e){
	   this.rollback();
   }
    }

    public void transactionF() throws SQLException, NoResultException {
        try{
    	int S = this.getSValue();
        int F = this.getFValue();
        int W = this.getWValue();
        int Z = this.getZValue();
        int V = this.getVValue();
        int U = this.getUValue();

        this.setFValue(F+U+V+Z+W);
        this.setSValue(S+U+V+Z+W);
        this.commit();
        
	}catch (SQLException e){
	   this.rollback();
   }
    }
    
    public void transactionG() throws SQLException, NoResultException {
        try{
    	this.setYValue(this.getYValue() + 1);
        this.setXValue(this.getXValue() - 1);
        this.setZValue(this.getZValue() + 1);
        this.setWValue(this.getWValue() - 1);
        this.commit();
        
	}catch (SQLException e){
	   this.rollback();
   }
    }

    public void transactionH() throws SQLException, NoResultException {
    	try{
        this.setWValue(this.getWValue() + 1);
        this.setZValue(this.getZValue() - 1);
        this.setXValue(this.getXValue() + 1);
        this.setYValue(this.getYValue() - 1);
        this.commit();
        
	}catch (SQLException e){
	   this.rollback();
   }
    }

    public void transactionI() throws SQLException, NoResultException {
        try{
    	int S = this.getSValue();
        int I = this.getIValue();
        int W = this.getWValue();
        int Z = this.getZValue();
        int Y = this.getYValue();
        int X = this.getXValue();

        this.setIValue(I+X+Y+Z+W);
        this.setSValue(S+X+Y+Z+W);
        this.commit();
        
	}catch (SQLException e){
	   this.rollback();
   }
    }


    public void commit() throws SQLException {
        try{
        	this.connection.commit();
        }catch(SQLException e){
        	e.printStackTrace();
        }
    	
    }
    public void rollback() throws SQLException {
     try{
    	 this.connection.rollback();
     }catch(SQLException e){
    	 e.printStackTrace();
     }
    	
    }
}
