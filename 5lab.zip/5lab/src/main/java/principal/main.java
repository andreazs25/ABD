package principal;
import java.sql.SQLException;

import conexion.Data;

public class main {

    public static Data data;

    public main() {
    }

    public static void main(String [ ] args) throws SQLException {
        	data = new Data("rooto", "mondra", "");
            data.initializeVariables();

            Executer executer = new Executer();

            executer.run();
     
        
    	
    }

}
