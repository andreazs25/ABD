package transactions;

import java.sql.SQLException;

import conexion.Data;

public class GestorTransaction extends Thread{

	protected static final int ITERATIONS = 100;
    protected String threadId;
    protected Data data;
    protected ThreadMode threadMode;
    protected LockMode lockMode;

    public GestorTransaction(ThreadMode threadMode, LockMode lockMode, String logName) {
        this.lockMode = lockMode;
        this.threadMode = threadMode;
        this.threadId = logName;
    }
    public void run() {
        try {
            init();
            try {
                this.data.showValues();
            } catch (Exception error) {}

            for(int i = 0; i < ITERATIONS ; i++) {
                try {
                    transaction();
                } catch (TransactionThreadError | Exception error) {
                    System.err.println("Error in the transaction: " + error.getMessage());
                    i--;
                }
            }
            
            this.data.showValues();
    
        } catch (SQLException e) {
            System.err.println("There was an error executing a sql sentence: " + e.getMessage());
        } catch (NoResultException e) {
            System.err.println("There was no result from the database.");
        } catch (TransactionThreadError transactionThreadError) {
            System.err.println("There was an error in the transaction:" + transactionThreadError.getMessage());
        }

        try {
            end();
        } catch (SQLException e) {
            System.err.println("There was an error trying to close the connection.");
        }

    }
    protected void end() throws SQLException {
        if(this.data.isConnected())
            this.data.dispatch();
        else
            System.out.println("This holder is not connected");
    }

    protected void init() throws TransactionThreadError {
        System.out.println("Initializing runner.");
        try {
            this.data = new Data("rooto", "mondra", threadId);
            this.data.setLocking(this.threadMode);
            this.data.setLockMode(this.lockMode);

        } catch (SQLException e) {
            throw new TransactionThreadError(e);
        }
    }
    protected void transaction() throws TransactionThreadError {
        try {
            if (this.threadId == "A"){
            	this.data.transactionA();
            }else if (this.threadId == "B"){
            	this.data.transactionB();
            }else if (this.threadId == "C"){
            	this.data.transactionC();
            }else if (this.threadId == "D"){
            	this.data.transactionD();
            }else if (this.threadId == "E"){
            	this.data.transactionE();
            }else if (this.threadId == "F"){
            	this.data.transactionF();
            } else if (this.threadId == "G"){
            	this.data.transactionG();
            } else if (this.threadId == "H"){
            	this.data.transactionH();
            } else if (this.threadId == "I"){
            	this.data.transactionI();
            } 
        } catch (SQLException e) {
            throw new TransactionThreadError(e);
        } catch (NoResultException e) {
            throw new TransactionThreadError();
        }
    }
}
