package transactions;

public enum  LockMode {
    EXCLUSIVE(0),
    SHARED(1);

    private final int value;

    LockMode(final int newValue) {
        value = newValue;
    }

    public int getValue() { return value; }
}
