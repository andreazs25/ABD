package transactions;

public enum LockingMode {
    NON_LOCKING(1),
    LOCKING(0);

    private final int value;

    LockingMode(final int newValue) {
        value = newValue;
    }

    public int getValue() { return value; }
}