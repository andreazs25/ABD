package transactions;

public class NoResultException extends Throwable {
}
