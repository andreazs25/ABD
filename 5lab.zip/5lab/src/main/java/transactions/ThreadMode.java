package transactions;


public enum ThreadMode {
    NON_LOCKING(0),
    LOCKING(1);

    private final int value;

    ThreadMode(final int newValue) {
        value = newValue;
    }

    public int getValue() { return value; }
}
