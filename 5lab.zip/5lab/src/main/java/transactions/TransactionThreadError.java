package transactions;

public class TransactionThreadError extends Throwable {
    public TransactionThreadError(Exception e) {
        super(e);
    }

    public TransactionThreadError(){}
}
