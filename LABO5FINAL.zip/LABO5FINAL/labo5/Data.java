package labo5;

import java.sql.*;

public class Data{
	
	Connection conn;
	Statement st;
	String sentence;
	static final String X = "X";
	static final String Y = "Y";
	static final String Z = "Z";
	static final String T = "T";
	static final String A = "A";
	static final String B = "B";
	static final String C = "C";
	static final String D = "D";
	static final String E = "E";
	static final String F = "F";
	static final String M = "M";
	
	static final int NONLOCKING = 0;
	static final int LOCKING = 1;
	static final int SHARE_LOCKING = LOCKING;
	static final int EXCLUSIVE_LOCKING = 2*LOCKING;
	static final int NUMBER_OF_ITERATIONS = 100;
	
	public Data() {
		//Load Mysql Driver
		try {
			Class.forName("org.gjt.mm.mysql.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		// Open connection
		try {
			conn = DriverManager.getConnection("jdbc:mysql://192.168.56.11:3306", "andrea", "1234");
			conn.setAutoCommit(false);
			st = conn.createStatement();
			initializeSharedVariables();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void initializeSharedVariables()  {

			try {
				setValue(X,0);
				setValue(Y,0);
				setValue(Z,0);
				setValue(T,0);
				setValue(A,0);
				setValue(B,0);
				setValue(C,0);
				setValue(D,0);
				setValue(E,0);
				setValue(F,0);
				commit();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				rollback();
			}
			
		
	}
	/**
	public int getXValue(int mode) throws SQLException {
		int valor=0;
			valor=getValue("X", mode);
		
		return valor;
	}
	
	public int getYValue(int mode)throws SQLException  {
		int valor=0;

			valor=getValue("Y", mode);

		return valor;
	}
	
	public int getZValue(int mode) throws SQLException {
		int valor=0;
			valor=getValue("Z", mode);
		
		return valor;
	}
	**/
	private boolean setValue(String valueName, int value) throws SQLException {
		PreparedStatement statement;
		statement = conn.prepareStatement(
				"UPDATE concurrency_control.variables SET value=? WHERE name=?");
			
		statement.setInt(1,value);
		statement.setString(2,valueName);
		statement.executeUpdate();
		statement.close();
		return true;
	}
	
	private boolean setValue(int mode, String valueName, int value) throws SQLException {
		PreparedStatement statement;
		statement = conn.prepareStatement(
				"UPDATE concurrency_control.variables SET value=? WHERE name=?");
			
		statement.setInt(1,value);
		statement.setString(2,valueName);
		statement.executeUpdate();
		statement.close();
		return true;
	}
	
	private int getValue(String valueName, int mode) throws SQLException {
		int id = -1;
		PreparedStatement statement;
		if (mode == Data.NONLOCKING) {
			statement = conn.prepareStatement("SELECT * FROM concurrency_control.variables WHERE name =?");
		} else {
			statement = conn.prepareStatement("SELECT * FROM concurrency_control.variables WHERE name =? FOR UPDATE");
		}
		statement.setString(1,valueName);
		ResultSet rs = statement.executeQuery();
		while (rs.next()) {
			id = rs.getInt("value");
		}
		rs.close();
		statement.close();
		return id;
	}
	
	public int getValue(int mode, String valueName) throws SQLException {
		int id = -1;
		PreparedStatement statement;
		if (mode == Data.NONLOCKING) {
			statement = conn.prepareStatement("SELECT * FROM concurrency_control.variables WHERE name =?");
		} else {
			statement = conn.prepareStatement("SELECT * FROM concurrency_control.variables WHERE name =? FOR UPDATE");
		}
		statement.setString(1,valueName);
		ResultSet rs = statement.executeQuery();
		while (rs.next()) {
			id = rs.getInt("value");
		}
		rs.close();
		statement.close();
		return id;
	}
	
	
	public void commit() {
		try {
			conn.commit();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void rollback(){
		try {
			conn.rollback();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public Boolean procedureA(String name, int cont, int myShareMode, int myExclusiveMode) {
		boolean esta = true;
		try {
			int x = getValue(myExclusiveMode, X);
			x = x + 1;
			setValue(myExclusiveMode, X, x);
			System.out.println("WRITE(" + name + Integer.toString(cont + 1) + "," + X + ";" + Integer.toString(x - 1)
					+ Integer.toString(x) + ")");
			int t = getValue(myExclusiveMode, T);
			int a = getValue(myExclusiveMode, A);
			int y = getValue(myShareMode, Y);
			t = t + y;
			a = a + y;
			setValue(myExclusiveMode, T, t);
			setValue(myExclusiveMode, A, a);
			System.out.println("WRITE(" + name + Integer.toString(cont + 1) + "," + T + "," + Integer.toString(t - y)
					+ "," + Integer.toString(t) + ")");
			System.out.println("WRITE(" + name + Integer.toString(cont + 1) + "," + A + "," + Integer.toString(a - y)
					+ "," + Integer.toString(a) + ")");
			System.out.println("END TRANSACTION" + name + Integer.toString(cont + 1));
			this.commit();
		} catch (SQLException e) {
			esta = false;
			this.rollback();
			e.printStackTrace();
		}
		return esta;
	}

	public Boolean procedureB(String name, int cont, int myShareMode, int myExclusiveMode) {
		boolean esta = true;
		try {
			int y = getValue(myExclusiveMode, Y);
			y = y + 1;
			setValue(myExclusiveMode, Y, y);
			System.out.println("WRITE(" + name + Integer.toString(cont + 1) + "," + Y + ";" + Integer.toString(y - 1)
					+ Integer.toString(y) + ")");
			int t = getValue(myExclusiveMode, T);
			int b = getValue(myExclusiveMode, B);
			int z = getValue(myShareMode, Z);
			t = t + z;
			b = b + z;
			setValue(myExclusiveMode, T, t);
			setValue(myExclusiveMode, B, b);
			System.out.println("WRITE(" + name + Integer.toString(cont + 1) + "," + T + "," + Integer.toString(t - z)
					+ "," + Integer.toString(t) + ")");
			System.out.println("WRITE(" + name + Integer.toString(cont + 1) + "," + B + "," + Integer.toString(b - z)
					+ "," + Integer.toString(b) + ")");

			System.out.println("END TRANSACTION" + name + Integer.toString(cont + 1));
			this.commit();
		} catch (SQLException e) {
			esta = false;
			this.rollback();
			e.printStackTrace();
		}
		return esta;

	}

	public Boolean procedureC(String name, int cont, int myShareMode, int myExclusiveMode) {
		boolean esta = true;
		try {
			int z = getValue(myExclusiveMode, Z);
			z = z + 1;
			setValue(myExclusiveMode, Z, z);
			System.out.println("WRITE(" + name + Integer.toString(cont + 1) + "," + Z + ";" + Integer.toString(z - 1)
					+ Integer.toString(z) + ")");
			int t = getValue(myExclusiveMode, T);
			int c = getValue(myExclusiveMode, C);
			int x = getValue(myShareMode, X);
			t = t + x;
			c = c + x;
			setValue(myExclusiveMode, T, t);
			setValue(myExclusiveMode, C, c);
			System.out.println("WRITE(" + name + Integer.toString(cont + 1) + "," + T + "," + Integer.toString(t - x)
					+ "," + Integer.toString(t) + ")");
			System.out.println("WRITE(" + name + Integer.toString(cont + 1) + "," + C + "," + Integer.toString(c - x)
					+ "," + Integer.toString(c) + ")");

			System.out.println("END TRANSACTION" + name + Integer.toString(cont + 1));
			this.commit();
		} catch (SQLException e) {
			esta = false;
			this.rollback();
			e.printStackTrace();
		}
		return esta;
	}

	public Boolean procedureD(String name, int cont, int myShareMode, int myExclusiveMode) {
		boolean esta = true;
		try {
			int t = getValue(myExclusiveMode, T);
			int d = getValue(myExclusiveMode, D);
			int z = getValue(myShareMode, Z);
			t = t + z;
			d = d + z;
			setValue(myExclusiveMode, T, t);
			setValue(myExclusiveMode, D, d);
			System.out.println("WRITE(" + name + Integer.toString(cont + 1) + "," + T + "," + Integer.toString(t - z)
					+ "," + Integer.toString(t) + ")");
			System.out.println("WRITE(" + name + Integer.toString(cont + 1) + "," + D + "," + Integer.toString(d - z)
					+ "," + Integer.toString(d) + ")");
			int x = getValue(myExclusiveMode, X);
			x = x - 1;
			setValue(myExclusiveMode, X, x);
			System.out.println("WRITE(" + name + Integer.toString(cont + 1) + "," + X + "," + Integer.toString(x + 1)
					+ "," + Integer.toString(x) + ")");
			System.out.println("END TRANSACTION" + name + Integer.toString(cont + 1));
			this.commit();
		} catch (SQLException e) {
			esta = false;
			this.rollback();
			e.printStackTrace();
		}
		return esta;
	}

	public Boolean procedureE(String name, int cont, int myShareMode, int myExclusiveMode) {
		boolean esta = true;
		try {
			int t = getValue(myExclusiveMode, T);
			int e = getValue(myExclusiveMode, E);
			int x = getValue(myShareMode, X);
			t = t + x;
			e = e + x;
			setValue(myExclusiveMode, T, t);
			setValue(myExclusiveMode, E, e);
			System.out.println("WRITE(" + name + Integer.toString(cont + 1) + "," + T + "," + Integer.toString(t - x)
					+ "," + Integer.toString(t) + ")");
			System.out.println("WRITE(" + name + Integer.toString(cont + 1) + "," + E + "," + Integer.toString(e - x)
					+ "," + Integer.toString(e) + ")");
			int y = getValue(myExclusiveMode, Y);
			y = y - 1;
			setValue(myExclusiveMode, Y, y);
			System.out.println("WRITE(" + name + Integer.toString(cont + 1) + "," + Y + "," + Integer.toString(y + 1)
					+ "," + Integer.toString(y) + ")");
			System.out.println("END TRANSACTION" + name + Integer.toString(cont + 1));
			this.commit();
		} catch (SQLException e) {
			esta = false;
			this.rollback();
			e.printStackTrace();
		}
		return esta;
	}

	public Boolean procedureF(String name, int cont, int myShareMode, int myExclusiveMode) {
		boolean esta = true;
		try {
			int t = getValue(myExclusiveMode, T);
			int f = getValue(myExclusiveMode, F);
			int y = getValue(myShareMode, Y);
			t = t + y;
			f = f + y;
			setValue(myExclusiveMode, T, t);
			setValue(myExclusiveMode, F, f);
			System.out.println("WRITE(" + name + Integer.toString(cont + 1) + "," + T + "," + Integer.toString(t - y)
					+ "," + Integer.toString(t) + ")");
			System.out.println("WRITE(" + name + Integer.toString(cont + 1) + "," + F + "," + Integer.toString(f - y)
					+ "," + Integer.toString(f) + ")");
			int z = getValue(myExclusiveMode, Z);
			z = z - 1;
			setValue(myExclusiveMode, Z, z);
			System.out.println("WRITE(" + name + Integer.toString(cont + 1) + "," + Z + "," + Integer.toString(z + 1)
					+ "," + Integer.toString(z) + ")");
			System.out.println("END TRANSACTION" + name + Integer.toString(cont + 1));
			this.commit();
		} catch (SQLException e) {
			esta = false;
			this.rollback();
			e.printStackTrace();
		}
		return esta;
	}

	

	public void cerrarConexion(){
		try {
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public boolean showVariableValues(String thread, String time){
		try {
			System.out.println("Hilo: "+thread+"\tTiempo: "+time);
			System.out.println("El valor de X es: "+getValue(0,X));
			System.out.println("El valor de Y es: "+getValue(0,Y));
			System.out.println("El valor de Z es: "+getValue(0,Z));
			System.out.println("El valor de T es: "+getValue(0,T));
			System.out.println("El valor de A es: "+getValue(0,A));
			System.out.println("El valor de B es: "+getValue(0,B));
			System.out.println("El valor de C es: "+getValue(0,C));
			System.out.println("El valor de D es: "+getValue(0,D));
			System.out.println("El valor de E es: "+getValue(0,E));
			System.out.println("El valor de F es: "+getValue(0,F));
			commit();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			rollback();
			e.printStackTrace();
		}
		return true;

	}

}
