package labo5;



public class ExcepcionConectarBD extends Exception{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ExcepcionConectarBD(){
		super();
	}
	
}