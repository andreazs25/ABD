package labo5;



public class Main {
	
	public void myMethod(){
		MyThreadA new1 = new MyThreadA(Data.LOCKING);
		MyThreadB new2 = new MyThreadB(Data.LOCKING);
		MyThreadC new3 = new MyThreadC(Data.LOCKING);
		MyThreadD new4 = new MyThreadD(Data.LOCKING);
		MyThreadE new5 = new MyThreadE(Data.LOCKING);
		MyThreadF new6 = new MyThreadF(Data.LOCKING);
		new1.start();
		new2.start();
		new3.start();
		new4.start();
		new5.start();
		new6.start();
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Main m = new Main();
		m.myMethod();

	}

}
