package labo5;

import java.sql.SQLException;

public class MyThreadE extends Thread{

	String myName = "E";
	Data myData;
	int myShareMode;
	int myExclusiveMode;
	
	MyThreadE(){
		this(Data.NONLOCKING);
	}
	
	public MyThreadE(int pMode) {
		myData= new Data();
		if(pMode == myData.NONLOCKING){
			myShareMode = myExclusiveMode = pMode;
		}else{
			myShareMode = myData.SHARE_LOCKING;
			myExclusiveMode = myData.EXCLUSIVE_LOCKING;
		}
		
	}
	
	public void run(){
		int counter = 0;
		Boolean committed;
			myData.showVariableValues(myName,"Initial");

		int myMode = this.getMode();
		while(counter < Data.NUMBER_OF_ITERATIONS){
				committed = myData.procedureE(myName,counter,myShareMode,myExclusiveMode);
			if (committed == true){
				counter = counter+1;
			}
		}
		

			myData.showVariableValues(myName, "Final");

		try{
			
			System.out.println();
			System.out.println("Expected final value of T -->" + Integer.toString(myData.getValue(getMode(), "T")));
		} catch(SQLException e){
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		myData.cerrarConexion();
	}
	
	public int getMode(){
		if(this.myShareMode == 1 && this.myExclusiveMode == 0){
			return 0;
		}
		else if(this.myExclusiveMode == 1 && this.myShareMode == 0){
			return 1;
		}
		else{
			return 0;
		}
	}
}
