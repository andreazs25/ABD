package conexion;

import java.sql.*;

public class Data {

	Connection conn;
	Statement st;
	String sentence;
	
	static final int NONLOCKING = 0;
	static final int LOCKING = 1;
	
	public static final int SHARE_LOCKING = LOCKING;
	static final int EXCLUSIVE_LOCKING = 2 * LOCKING;
	static final int NUMBER_OF_ITERATIONS = 10;
	
	static final String X = "X";
	static final String Y = "Y";
	static final String Z = "Z";
	static final String W = "W";
	static final String S = "S";
	static final String C = "C";
	static final String F = "F";
	static final String U = "U";
	static final String V = "V";
	static final String I = "I";

	public Data() {

		// Load MySQL driver
		try {
			Class.forName("org.gjt.mm.mysql.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		// Open connection
		try {
			conn = DriverManager.getConnection("jdbc:mysql://192.168.56.10:3306", "rooty", "rooty");

			conn.setAutoCommit(false);
			st = conn.createStatement();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public Boolean showVariableValues(String thread, String time) {
		int x = getValue(0, X);
		int y = getValue(0, Y);
		int z = getValue(0, Z);
		int w = getValue(0, W);
		int s = getValue(0, S);
		int c = getValue(0, C);
		int f = getValue(0, F);
		int u = getValue(0, U);
		int v = getValue(0, V);
		int i = getValue(0, I);

		if (x == -1 || y == -1 || z == -1 || w == -1 || s == -1 || c == -1 || f == -1 || u == -1 || v == -1
				|| i == -1) {
			return false;
		}
		System.out.println("Hilo " + thread);
		System.out.println("El valor de X es:" + getValue(0, "X"));
		System.out.println("El valor de Y es: " + getValue(0, "Y"));
		System.out.println("El valor de Z es: " + getValue(0, "Z"));
		System.out.println("El valor de W es: " + getValue(0, "W"));
		System.out.println("El valor de S es: " + getValue(0, "S"));
		System.out.println("El valor de C es: " + getValue(0, "C"));
		System.out.println("El valor de F es: " + getValue(0, "F"));
		System.out.println("El valor de U es: " + getValue(0, "U"));
		System.out.println("El valor de V es: " + getValue(0, "V"));
		System.out.println("El valor de I es: " + getValue(0, "I"));
		System.out.println("Tiempo " + time);
		return true;
	}

	public Boolean initilizeSharedVariables() {
		setValue(LOCKING, X, 0);
		setValue(LOCKING, Y, 0);
		setValue(LOCKING, Z, 0);
		setValue(LOCKING, W, 0);
		setValue(LOCKING, S, 0);
		setValue(LOCKING, C, 0);
		setValue(LOCKING, F, 0);
		setValue(LOCKING, U, 0);
		setValue(LOCKING, V, 0);
		setValue(LOCKING, I, 0);// ES COMO SI LO GUARDARA EN UN TEPORAAL
		commit();// lo guarda de forma permanente
		return true;
	}

	public int getValue(int mode, String variable) {
		int i = -1;
		try {
			PreparedStatement statement;
			if (mode == EXCLUSIVE_LOCKING) {
				statement = conn
						.prepareStatement("SELECT * FROM currency_control.variables WHERE name=? FOR UPDATE");

			} else if (mode == SHARE_LOCKING) {
				statement = conn.prepareStatement(
						"SELECT * FROM currency_control.variables WHERE name=? LOCK IN SHARE MODE");
			} else {
				// sin bloqueo
				statement = conn.prepareStatement("SELECT * FROM currency_control.variables WHERE name=?");
			}

			statement.setString(1, variable);
			ResultSet rs = statement.executeQuery();

			while (rs.next()) {
				i = rs.getInt("value");
			}

			rs.close();
			statement.close();
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return i;

	}

	public Boolean setValue(int mode, String variable, int value) {
		boolean devolver = true;

		try {

			PreparedStatement statement;
			if (mode == EXCLUSIVE_LOCKING) {
				getValue(EXCLUSIVE_LOCKING, variable);
			} else if (mode == SHARE_LOCKING) {
				getValue(SHARE_LOCKING, variable);
			} else {
				// sin bloqueo
				getValue(NONLOCKING, variable);
			}
			statement = conn.prepareStatement("UPDATE currency_control.variables SET value=? WHERE name=? ");

			statement.setInt(1, value);
			statement.setString(2, variable);
			statement.executeUpdate();
			statement.close();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			devolver = false;
			e.printStackTrace();

		}

		return devolver;
	}

	public void commit() {
		try {
			conn.commit();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			rollback();
			e.printStackTrace();
		}
	}

	public void rollback() {
		try {
			conn.rollback();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public boolean transaccionG(String myName, int counter, int myShareMode, int myExclusiveMode) {
		boolean esta = false;
		boolean esta1 = false;
		boolean esta2 = false;
		boolean esta3 = false;
		
		int y = getValue(myShareMode, Y);
		y = y + 1;
		esta = setValue(myExclusiveMode, Y, y);
		int x = getValue(myShareMode, X);
		x = x - 1;
		esta1 = setValue(myExclusiveMode, X, x);
		int z = getValue(myShareMode, Z);
		z = z + 1;
		esta2 = setValue(myExclusiveMode, Z, z);
		int w = getValue(myShareMode, W);
		w = w - 1;
		esta3 = setValue(myExclusiveMode, W, w);

		if (esta || esta1 || esta2 || esta3) {
			esta = true;
			System.out.println("miramos la  variable x ="+""+x);
			System.out.println("miramos la  variable y ="+""+y);
			System.out.println("miramos la  variable z ="+""+z);
			System.out.println("miramos la  variable w ="+""+w);
			rollback();
		}else{
			this.commit();
		}

		return esta;
	}

	public boolean transaccionH(String myName, int counter, int myShareMode, int myExclusiveMode) {
		boolean esta = false;
		boolean esta1 = false;
		boolean esta2 = false;
		boolean esta3 = false;
		int w = getValue(myShareMode, W);
		w = w + 1;
		esta = setValue(myExclusiveMode, W, w);
		int z = getValue(myShareMode, Z);
		z = z - 1;
		esta1 = setValue(myExclusiveMode, Z, z);
		int x = getValue(myShareMode, X);
		x = x + 1;
		esta2 = setValue(myExclusiveMode, X, x);
		int y = getValue(myShareMode, Y);
		y = y - 1;
		esta3 = setValue(myExclusiveMode, Y, y);

		if (esta || esta1 || esta2 || esta3) {
			esta = true;
			System.out.println("miramos la  variable w ="+""+w);
			System.out.println("miramos la  variable z ="+""+z);
			System.out.println("miramos la  variable x ="+""+x);
			System.out.println("miramos la  variable y ="+""+y);
			rollback();
		}

		return esta;
	}

	public boolean transaccionI(String myName, int counter, int myShareMode, int myExclusiveMode) {
		boolean esta = false;
		boolean esta1 = false;

		int s = getValue(myShareMode, S);
		int i = getValue(myShareMode, I);
		int w = getValue(myShareMode, W);
		int z = getValue(myShareMode, Z);
		int y = getValue(myShareMode, Y);
		int x = getValue(myShareMode, X);

		i = i + x + y + z + w;
		esta = setValue(myExclusiveMode, I, i);
		s = s + x + y + z + w;
		esta1 = setValue(myExclusiveMode, S, s);

		if (esta || esta1) {
			esta = true;
			System.out.println("miramos la  variable s ="+""+s);
			System.out.println("miramos la  variable i ="+""+i);
			System.out.println("miramos la  variable w ="+""+w);
			System.out.println("miramos la  variable z ="+""+z);
			System.out.println("miramos la  variable y ="+""+y);
			System.out.println("miramos la  variable x ="+""+x);
			rollback();
		}

		return esta;
	}

}
