package conexion;

import java.sql.SQLException;

public class Main {
	
	public static void main(String[] args) throws SQLException {
		
		
		
		Data myData = new Data();
		
		Integer mode = 1;
		
		
		
		ThreadGeneral threadG = new ThreadGeneral("G", mode);
		ThreadGeneral threadH = new ThreadGeneral("H", mode);
		ThreadGeneral threadI = new ThreadGeneral("I", mode);
	
		
	
		
		myData.initilizeSharedVariables();
		threadG.start();
		threadH.start();
		threadI.start();

		
		
		
	
		/**
		ThreadGeneral threadw = new ThreadGeneral("W",0,0);
		ThreadGeneral threads = new ThreadGeneral("S",0,0);
		ThreadGeneral threadc = new ThreadGeneral("C",0,0);
		ThreadGeneral threadf = new ThreadGeneral("F",0,0);
		ThreadGeneral threadv = new ThreadGeneral("V",0,0);
		ThreadGeneral threadi = new ThreadGeneral("I",0,0);
		**/
		/**
		System.out.println(myData.showVariableValues("X", "12:52"));
		System.out.println(myData.transaccionG("x", 0, 0, 0));
		
		new Thread(threadx).start();
		new Thread(thready).start();
		new Thread(threadz).start();
		new Thread(threadw).start();
		new Thread(threads).start();
		new Thread(threadc).start();
		new Thread(threadf).start();
		new Thread(threadv).start();
		new Thread(threadi).start();
		**/
	}
	
	
	
}

