package conexion;

import java.sql.SQLException;

import errors.TransactionThreadError;

public class ThreadGeneral extends Thread {
	// Atributes
	String myName;
	Data myData;
	int myShareMode;
	int myExclusiveMode;

	ThreadGeneral(String pMyName) {//sin reservas
		// constructor
		myData=new Data();
		this.myName = pMyName;
		this.myShareMode = myData.NONLOCKING;
		this.myExclusiveMode = myData.NONLOCKING;

	}
	ThreadGeneral(String nombre, int mode){
		this(nombre);
		if(mode == myData.LOCKING){
			myShareMode = myData.SHARE_LOCKING;
			myExclusiveMode = myData.EXCLUSIVE_LOCKING;

		}
	}




	public void run() {
		// concurrent process
		int counter = 0;


		this.myData.showVariableValues(myName, "Initial");
		boolean commited;
		while (counter < Data.NUMBER_OF_ITERATIONS) {
			if (myName.equals("G")) {
				commited = this.myData.transaccionG(myName, counter, myShareMode, myExclusiveMode);
			}
			if (myName.equals("H")) {
				commited = this.myData.transaccionH(myName, counter, myShareMode, myExclusiveMode);
			}
			if (myName.equals("I")) {
			}
			commited = this.myData.transaccionI(myName, counter, myShareMode, myExclusiveMode);

			if (commited == true) {
				counter = counter + 1;

				myData.showVariableValues(myName, "final");
			} else {
				counter=-1;
			}
		}

	}
}
