package errors;

public class NoResultException extends Throwable {
}
